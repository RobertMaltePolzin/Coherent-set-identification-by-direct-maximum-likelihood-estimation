
N_cluster = 7; % number of clusters   
figure;
IDX=kmeans((U(:,1:N_cluster)),N_cluster);


test1=find(IDX==1);
test2=find(IDX==2);
test3=find(IDX==3);
test4=find(IDX==4);
test5=find(IDX==5);
test6=find(IDX==6);
test7=find(IDX==7);

scatter3(b(test2,1),b(test2,2),b(test2,3),30,'filled','red');
hold on
scatter3(b(test3,1),b(test3,2),b(test3,3),30,'filled','green');
hold on
scatter3(b(test4,1),b(test4,2),b(test4,3),30,'filled','blue');
hold on
scatter3(b(test5,1),b(test5,2),b(test5,3),30,'filled','yellow');
hold on
scatter3(b(test6,1),b(test6,2),b(test6,3),30,'filled','magenta');
hold on
scatter3(b(test7,1),b(test7,2),b(test7,3),30,'filled','cyan');

axis equal
axis tight
