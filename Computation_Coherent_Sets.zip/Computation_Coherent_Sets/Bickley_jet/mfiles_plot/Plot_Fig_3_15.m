%% ABC flow
% Mat-file are in the folder Chapter3\mat_files

clear all
clc

FileName   = 'ABC_flow_depth_12.mat';
FolderName = ['..' filesep 'MATLAB']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);

%%% all t %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,400]); % plot width and height
axes('Units', 'normalized', 'Position',[10*delt, 18*delt, 1-15*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

velocity=v(b,0);
quiver3(b(:,1),b(:,2),b(:,3),velocity(:,1),velocity(:,2),velocity(:,3),3)
axis equal
axis tight
set(gca,'FontSize',16)
%ylim([min(b(:,2)) max(b(:,2))]);
%xlim([0 20]);

%%% all t %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,400]); % plot width and height
axes('Units', 'normalized', 'Position',[10*delt, 18*delt, 1-15*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

Z = sqrt(velocity(:,1).^2 +velocity(:,2).^2);
scatter3(b(:,1),b(:,2),b(:,3),30,Z,'filled')
colorbar;
caxis([0 3]);
axis equal
axis tight
set(gca,'FontSize',16)


