%% Example Bickley jet
% Mat-file are in the folder Chapter3\mat_files

clear all
clc

FileName   = 'Bickley_jet_depth_14.mat';
FolderName = ['..' filesep 'MATLAB']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);

[n m]=size(P_hat);
Q=P_hat'*P_hat-eye(m,m);

generator=exp(Q);
[VV DD]=eigs(generator,24);
[VVV DDD]=eigs(P_hat'*P_hat,24);

%%% Singular values %%%

figure;
kk=24;
plot([1:kk],diag(S(1:kk,1:kk),0),'r.','MarkerSize',24);
hold on
plot([1:kk],diag(DDD(1:kk,1:kk),0),'g.','MarkerSize',24);
xticks([1:24]);
xlabel({'$l$'},'Interpreter','latex','FontSize', 16);
ylabel({'$\sigma_{l},\lambda_{l}$'},'Interpreter','latex', 'FontSize', 16);
ylim([DDD(kk,kk) 1]);
xlim([1 24]);
leg2=legend('$\sigma_{l}(\hat P_{\varepsilon})$','$\lambda_{l}(\hat P_{\varepsilon}^T\hat P_{\varepsilon})$','Interpreter','latex','FontSize', 16);

%%% Singular function %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,416,180]); % plot width and height
axes('Units', 'normalized', 'Position',[10*delt, 18*delt, 1-18*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

scatter(b(:,1),b(:,2),30,VV(:,1),'filled');

axis equal
axis tight
colorbar
xlim([0 20]);

caxis([0.022821 0.022822]);
