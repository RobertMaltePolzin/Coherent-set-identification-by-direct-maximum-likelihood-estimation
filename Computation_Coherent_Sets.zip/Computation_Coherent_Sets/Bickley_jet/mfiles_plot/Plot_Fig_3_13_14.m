%% Example Double Gyre
% Mat-file are in the folder Chapter3\mat_files

clear all
close all
clc

FileName   = 'Bickley_jet_depth_14.mat';
FolderName = ['..' filesep 'MATLAB']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,160]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-8*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

% Second right singular vector
scatter(b(:,1),b(:,2),30,V(:,2),'filled');
axis equal
axis tight
colorbar
caxis([-0.1 0.1]);
%xticks([0:0.5:2]);
%ylim([0 1]);
xlim([0 20]);

%%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,160]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-8*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

% Second right singular vector
scatter(b2(:,1),b2(:,2),30,U(:,2),'filled');
axis equal
axis tight
colorbar
caxis([-0.1 0.1]);
%xticks([0:0.5:2]);
%ylim([0 1]);
xlim([0 20]);

%%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,160]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-8*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

% Third right singular vector
scatter(b(:,1),b(:,2),30,V(:,9),'filled');
axis equal
axis tight
colorbar
caxis([-0.1 0.1]);
%xticks([0:0.5:2]);
%ylim([0 1]);
xlim([0 20]);

%%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,160]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-8*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

% Third left singular vector
scatter(b2(:,1),b2(:,2),30,U(:,9),'filled');
axis equal
axis tight
colorbar
caxis([-0.1 0.1]);
%xticks([0:0.5:2]);
%ylim([0 1]);
xlim([0 20]);


%%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,160]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

% Third left singular vector
N_cluster = 15; % number of clusters                                           
IDX=kmeans((V(:,1:N_cluster)),N_cluster);
scatter(b(:,1),b(:,2),30,IDX,'filled');
axis equal
axis tight
colorbar
caxis([0 20]);
%xticks([0:0.5:2]);
%ylim([0 1]);
xlim([0 20]);

%%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,160]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

% Third left singular vector
N_cluster = 15; % number of clusters                                           
IDX=kmeans((U(:,1:N_cluster)),N_cluster);
scatter(b2(:,1),b2(:,2),30,IDX,'filled');
axis equal
axis tight
colorbar
caxis([0 20]);
%xticks([0:0.5:2]);
%ylim([0 1]);
xlim([0 20]);

