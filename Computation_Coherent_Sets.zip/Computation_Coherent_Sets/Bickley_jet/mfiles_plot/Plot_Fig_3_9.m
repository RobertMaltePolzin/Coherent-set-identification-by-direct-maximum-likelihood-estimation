%% Example Bickley jet
% Mat-file are in the folder Chapter3\mat_files

clear all
clc

FileName   = 'Bickley_jet_depth_14.mat';
FolderName = ['..' filesep 'MATLAB']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);

%%% t=0 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,190]); % plot width and height
axes('Units', 'normalized', 'Position',[10*delt, 18*delt, 1-15*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

velocity=v1(b,0);
quiver(b(:,1),b(:,2),velocity(:,1),velocity(:,2))
axis equal
axis tight
set(gca,'FontSize',16)
ylim([min(b(:,2)) max(b(:,2))]);
xlim([0 20]);

%%% t=3.456*10^6 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,190]); % plot width and height
axes('Units', 'normalized', 'Position',[10*delt, 18*delt, 1-15*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

velocity=v1(b2,3.456*10^6);
quiver(b2(:,1),b2(:,2),velocity(:,1),velocity(:,2))
axis equal
axis tight
set(gca,'FontSize',16)
ylim([min(b2(:,2)) max(b2(:,2))]);
xlim([0 20]);

