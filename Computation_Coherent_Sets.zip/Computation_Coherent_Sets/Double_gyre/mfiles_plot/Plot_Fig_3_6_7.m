%% Plot of Figure 3.6 and 3.7

clear all
close all
clc

FileName   = 'double_gyre.mat';
FolderName = ['..' filesep 'mfiles_double_gyre']; % Computation_Coherent_Sets\Double_gyre\mfiles_double_gyre
File       = fullfile(FolderName, FileName);
load(File);

%%% Second right singular vector %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-8*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

scatter(b(:,1),b(:,2),30,V(:,2),'filled');
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [min(V(:,2))  (min(V(:,2)) +max(V(:,2)))/2 max(V(:,2))];

%%% Second left singular vector %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-8*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

scatter(b(:,1),b(:,2),30,U(:,2),'filled');
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [min(U(:,2))  (min(U(:,2)) +max(U(:,2)))/2 max(U(:,2))];

%%% Third right singular vector %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-8*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

scatter(b(:,1),b(:,2),30,V(:,3),'filled');
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [min(V(:,3))  (min(V(:,3)) +max(V(:,3)))/2 max(V(:,3))];

%%% Third left singular vector %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-8*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

scatter(b(:,1),b(:,2),30,U(:,3),'filled');
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [min(U(:,3))  (min(U(:,3)) +max(U(:,3)))/2 max(U(:,3))];


%%% k-means clustering with L=3 clusters %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])


N_cluster = 3; % number of clusters                                           
IDX=kmeans((V(:,1:N_cluster)),N_cluster);
scatter(b(:,1),b(:,2),30,IDX,'filled');
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [min(IDX) 2 max(IDX)];

%%% k-means clustering with L=3 clusters %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

% Third left singular vector
N_cluster = 3; % number of clusters                                           
IDX=kmeans((U(:,1:N_cluster)),N_cluster);
scatter(b(:,1),b(:,2),30,IDX,'filled');
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [min(IDX) 2 max(IDX)];
