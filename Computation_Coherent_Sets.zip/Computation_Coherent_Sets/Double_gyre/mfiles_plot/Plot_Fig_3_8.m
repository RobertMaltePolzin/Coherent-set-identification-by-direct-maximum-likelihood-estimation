
%% Plot of Figure 3.8

clear all
clc

FileName   = 'double_gyre.mat';
FolderName = ['..' filesep 'mfiles_double_gyre']; % Computation_Coherent_sets\Double_gyre\mfiles_double_gyre
File       = fullfile(FolderName, FileName);
load(File);

length_b=length(b);

[n m]=size(P_hat);

%% Rate matrix and matrix exponential
Q=P_hat'*P_hat/trace(P_hat'*P_hat)-eye(m,m);
matrix_exponential=exp(Q);

%% Eigenvalue decomposition
[VV DD]=eigs(matrix_exponential,length_b);

%%% First eigenfunction of matrix exponential with linearly approximated  %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-23*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

scatter(b(:,1),b(:,2),30,VV(:,1),'filled');

axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [min(VV(:,1)) -0.011048542983397 max(VV(:,1))];



