
%% Plot of Figure 3.5

clear all
clc

FileName   = 'double_gyre.mat';
FolderName = ['..' filesep 'mfiles_double_gyre']; % Computation_Coherent_Sets\Double_gyre\mfiles_double_gyre
File       = fullfile(FolderName, FileName);
load(File);

length_b=length(b);

[n m]=size(P_hat);

%% Rate matrix and matrix exponential
Q=P_hat'*P_hat/trace(P_hat'*P_hat)-eye(m,m);
matrix_exponential=exp(Q);

%% Eigenvalue decomposition
[VV DD]=eigs(matrix_exponential,length_b);
[VVVV DDDD]=eigs(P_hat'*P_hat,length_b);

%%% Plot of spectral values %%%

figure;
kk=12;
plot([1:kk],diag(S(1:kk,1:kk),0),'r.','MarkerSize',24);
hold on
plot([1:kk],diag(DDDD(1:kk,1:kk),0),'g.','MarkerSize',24);
xticks([1:20]);
xlabel({'$l$'},'Interpreter','latex','FontSize', 16);
ylabel({'$\sigma_{l},\lambda_{l}$'},'Interpreter','latex', 'FontSize', 16);
ylim([DDDD(kk,kk) 1]);
xlim([1 12]);
leg2=legend('$\sigma_{l}(\hat P_{\epsilon})$','$\lambda_{l}(\hat P_{\epsilon}^T\hat P_{\epsilon})$','Interpreter','latex','FontSize', 16);
