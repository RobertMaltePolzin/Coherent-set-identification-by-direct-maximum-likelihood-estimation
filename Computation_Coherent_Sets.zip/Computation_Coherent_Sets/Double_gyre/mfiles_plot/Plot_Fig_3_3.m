%% Plot of Figure 3.3

clear all
clc

FileName   = 'double_gyre.mat';
FolderName = ['..' filesep 'mfiles_double_gyre']; % Computation_Coherent_Sets\Double_gyre\mfiles_double_gyre
File       = fullfile(FolderName, FileName);
load(File);

%%% t=0 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,260]); % plot width and height
axes('Units', 'normalized', 'Position',[10*delt, 18*delt, 1-12*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

velocity=v(b,0);
quiver(b(:,1),b(:,2),velocity(:,1),velocity(:,2))
axis equal
axis tight
set(gca,'FontSize',16)
ylim([0 1]);
xlim([0 2]);

%%% t=0.25 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,260]); % plot width and height
axes('Units', 'normalized', 'Position',[10*delt, 18*delt, 1-12*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

velocity=v(b,0.25);
quiver(b(:,1),b(:,2),velocity(:,1),velocity(:,2))
axis equal
axis tight
set(gca,'FontSize',16)
ylim([0 1]);
xlim([0 2]);

%%% t=40.75 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,260]); % plot width and height
axes('Units', 'normalized', 'Position',[10*delt, 18*delt, 1-12*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

velocity=v(b,40.75);
quiver(b(:,1),b(:,2),velocity(:,1),velocity(:,2))
axis equal
axis tight
set(gca,'FontSize',16)
ylim([0 1]);
xlim([0 2]);
