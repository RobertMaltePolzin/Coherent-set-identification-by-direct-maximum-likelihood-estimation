function [T IJS In_Out N_cd] = tpmatrix_double_gyre(tree, f, X, depth, verbose)

% TPMATRIX   transition probability matrix.
%
%   TPMATRIX(t, f, X, d, v) computes the matrix T of transition
%   probabilities between the boxes in the tree t
%
%   t       tree containing the box covering
%   f       map
%   X       m x d-matrix of sample points, m test points
%   d       depth of the tree on which the matrix is computed
%   v       verbose flag: '0' or '1' ('1' prints progress)

d = tree.dim; %2
b = tree.boxes(depth);   % get the geometry of the boxes 128x6
N = size(b,2); %6

M=N; % Fall m=n
%structure with the fields
S=whos('X');
l = floor(5e7/S.bytes);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I = []; IJS = []; tic;
%% floor rounds M/l to the nearest integer less than or equal to M/l.
for k = 0:floor(M/l)   % split in chunks of size l
    floor(M/l)
    K = k*l+1:min((k+1)*l,M);
    c = b(1:d,K);      % centers of the boxes
    r = b(d+1:2*d,1);  % radii of the boxes
    n = size(c,2)     % anzahl boxen 2^7
    E = ones(n,1);
    
    H=X*diag(r);
    new=[];
    centers=[];
    JJ=[];
    
    P = kron(E,X)*diag(r) + kron(c',ones(size(X,1),1)); % sample points in all boxes
    
    I = tree.search(f(P)', depth);   % get box numbers of image points
    
    pI = find(I>0);  % I <= 0 iff f(P) is outside of covering
    pI2 = find(I<0);
    
    J = kron(K',ones(size(X,1),1));
    
    In_Out=[I(pI), J(pI)];
    
    [I,J,S] = find(sparse(I(pI), J(pI), 1,N,M));  % transition matrix
    
    %size(I)
    %size(J)
    
    IJS = [IJS; I,J,S];
    if verbose, fprintf('%d of %d boxes, %.1f sec\n',min((k+1)*l,N),N,toc); end
end

N_cd = sparse(IJS(:,1), IJS(:,2), IJS(:,3),N,M);


QQ=N_cd;
cs = sum(N_cd);
T=N_cd*spdiags(1./cs', 0, M, M);
if verbose, fprintf('\n'); end


