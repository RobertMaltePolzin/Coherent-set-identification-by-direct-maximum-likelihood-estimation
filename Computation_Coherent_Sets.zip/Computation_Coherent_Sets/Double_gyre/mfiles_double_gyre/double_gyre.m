%% Double gyre
% mat-files are in the folder Computation_Coherent_sets/Double_gyre/mfile_plot

clear all
clc

% loading GAIO from GAIOguy
addpath(genpath('../../GAIO'))

% depth for tree and perturbation size 
sd = 8; depth=13; 
sigma=1/2^(depth+1);

% Double Gyre vector field
A=0.25; delta=0.25; omega=2*pi; Tstart=0.25; h = 0.01;
v = @(x,T) [-pi*A*sin(pi*(delta*sin(omega*T)*x(:,1).^2+(1-2*delta*sin(omega*T))*x(:,1))).*cos(pi*x(:,2)) pi*A*cos(pi*(delta*sin(omega*T)*x(:,1).^2+(1-2*delta*sin(omega*T))*x(:,1))).*sin(pi*x(:,2)).*(delta*sin(omega*T)*2*x(:,1)+(1-2*delta*sin(omega*T)))];

%% time integrated vector field
% v is the vector field above
% x is the spatial coordinate
% h is the timestep is h
% n_time is the number of steps
% Tstart is the initial time number of steps to form the
n = 4050; n_time=4050; f = @(x) runge_kutta_4(v,x,h,n,Tstart,sigma);
n=10; n_box=10;
x = linspace(-1,1,n)';
[XX,YY] = meshgrid(x,x);
X = [ XX(:) YY(:) ];

%% initial box is [0,2]\times [0 1]
c = [1 0.5]; r = [1 0.5]; t = Tree(c,r);
%% construct tree
for i=1:depth,
    t.set_flags('all', sd);
    t.subdivide;
    fprintf('step %i: %i boxes\r', i, t.count(-1));
end
b=t.boxes(-1)';
%% GAIO output
tic % time for compuation
[A B C D]=tpmatrix_double_gyre(t, f, X, depth,1);
P=A';
IJS=B';
In_Out=C;
N_cd=D;

%% Compute transition matrix
P_new=N_cd*diag(1./sum(N_cd)); % transition matrix
p=sum(N_cd)/sum(N_cd(:)); % vector p
q=sum(N_cd')/sum(N_cd(:)); % vector q
P_hat=diag(q)^-0.5*P_new*diag(p)^0.5; % rescaling
toc

%% full matrix and SVD
P_hat=full(P_hat);
[U,S,V]  = svd(P_hat);

%% plot matrix
figure; imagesc(P_hat); colorbar;
title("Matrix $\hat P_{\epsilon}$ for perturbation size $\epsilon=$" + sigma + "",'Interpreter','latex', 'FontSize', 16)


