%% RK4   Runge-Kutta scheme of order 4
function X = runge_kutta_4(v,X,h,n,tstart,sigma)

% RK4   Runge-Kutta scheme of order 4
%   performs n steps of the scheme for the vector field v
%   using stepsize h on each row of the matrix X
%   v maps an (m x d)-matrix to an (m x d)-matrix
%   sigma is size of perturbation

for t=tstart:h:tstart+(n-1)*h;
    
    k1 = v(X,t);
    k2 = v(X + h/2*k1,t+h/2);
    k3 = v(X + h/2*k2,t+h/2);
    k4 = v(X + h*k3,t+h);
    
    
    if t==tstart
        % add noise for initial time
        X = X + h*(k1 + 2*k2 + 2*k3 + k4)/6+sigma*sqrt(h)*randn(length(X),2);
        
    elseif t==tstart+(n-1)*h
        
        X = X + h*(k1 + 2*k2 + 2*k3 + k4)/6;
        
    else
        X = X + h*(k1 + 2*k2 + 2*k3 + k4)/6;
        
    end
end

% add noise for fimal time
noise_new=sigma*sqrt(h)*randn(length(X),2);
X=X+noise_new;

%% reflecting boundary condition
X(find(X(:,1)>2),1)=2-(X(find(X(:,1)>2),1)-2);
X(find(X(:,2)>1),2)=1-(X(find(X(:,2)>1),2)-1);
X(find(X(:,1)<0),1)=-(X(find(X(:,1)<0),1));
X(find(X(:,2)<0),2)=-(X(find(X(:,2)<0),2));













